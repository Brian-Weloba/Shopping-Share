package com.saturdev.shoppingshare;

public class CountryData {
    public static final String[] countryNames = {"Kenya", "Rwanda", "South Africa",
            "Tanzania", "Uganda", "Zimbabwe"};

    public static final String[] countryAreaCodes = {"254", "250", "27", "255",
            "256", "263"};
}
